Shows the different behaviors of Pyro's server types.
First start the server, it will ask what type of server you want to run. 
The client will print some information about what's happening.

Try it with different server types and see how that changes the behavior.

You can also try to set ONEWAY_THREADED to False on the server side,
to change the behavior of oneway calls. The client will print a message
if it detects you have been fiddling with this ;-)
 